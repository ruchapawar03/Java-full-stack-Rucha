package com.springProj.springproj.service;

import java.util.List;

import com.springProj.springproj.entity.Employee;

public interface EmployeeService {
	
	public List<Employee> getAll();
	public Employee saveEmp(Employee emp);
	public Employee updateEmp(Employee emp);
	public Employee findById(long id);
	public void deleteEmp(long id);

}
